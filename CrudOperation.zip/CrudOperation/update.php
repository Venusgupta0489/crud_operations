<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<!-- css -->
<link rel="stylesheet" href="./CSS/update.css">
</head>


<body>


<div class="container register">
       <div class="row">
           <div class="col-md-3 register-left">
               <img src="image/crud.svg" alt="">
               <h3> welcome</h3>
               <p>please fill all the details</p>
               <a href="display.php"> check form</a> <br>
           </div>

           <div class="col-md-9 register-right">
               <div class="tab-content" id="myTabContent">
                   <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                     <h3 class="register-heading">Update here</h3>

                     <form action="" method="post">
                            <div class="row register-form">



<?php

require_once 'connection.php';


$ids = $_GET['id'];

$showquery = "select * from contactdetails where id={$ids}";

$showdata = mysqli_query($con, $showquery);

$arrdata = mysqli_fetch_array($showdata);

if (isset($_POST['submit'])) {
    $idupdate = $_GET['id'];

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $mobilenumber = $_POST['mobilenumber'];
    $fathername = $_POST['fathername'];
    $designation = $_POST['designation'];
    $message = $_POST['message'];



    $query = " update contactdetails set id=$idupdate, firstname='$firstname', lastname='$lastname', email='$email', mobilenumber='$mobilenumber', fathername='$fathername', designation='$designation', message='$message' where id=$idupdate";

    $res = mysqli_query($con, $query);

    if ($res) {
       echo "data updated";
} else {

      echo "Not Updated";

    }
    header('location:display.php');
}

?>





            <div class="col-md-6 one">

                                    <div class="form-group">
                                      <input type="text" class="form-control"  name="id" value="<?php echo $arrdata['id']; ?>" required/>
                                    </div>
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="enter your first name" name="firstname" value="<?php echo $arrdata['firstname']; ?>" required/>
                                    </div>

                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="enter your last name" name="lastname" value="<?php echo $arrdata['lastname']; ?>" required/>
                                    </div>

                                    <div class="form-group">
                                      <input type="email" class="form-control" placeholder="enter your email" name="email" value="<?php echo $arrdata['email']; ?>" required/>
                                    </div>

                </div>


                <div class="col-md-6 two">

                                    <div class="form-group">
                                      <input type="phone" class="form-control" placeholder="enter your mobile number " name="mobilenumber" value="<?php echo $arrdata['mobilenumber']; ?>" required/>
                                    </div>


                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="enter your father name" name="fathername" value="<?php echo $arrdata['fathername']; ?>" required/>
                                    </div>

                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Enter your designation" name="designation" value="<?php echo $arrdata['designation']; ?>" required/>
                                    </div>

                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Somthing about your self" name="message" value="<?php echo $arrdata['message']; ?>" required/>
                                    </div>

                                    <input type="submit" class="btnRegister" name="submit" value="update">

                </div>


</div>
</form>

</div>
</div>
</div>



</div>
</div>



    
</body>
</html>