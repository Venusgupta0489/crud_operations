<?php

require 'connection.php';
$ids = $_GET['id'];
$del = "DELETE FROM contactdetails Where id=$ids";

$res = mysqli_query($con,$del);
header('Location: display.php');


?>